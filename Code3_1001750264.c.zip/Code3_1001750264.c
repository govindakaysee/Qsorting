/* Govinda KC  1001750264 */
#include <stdio.h>
#include <stdlib.h>
#include<time.h>

//declaring the prototypes
void fillbingo (int BingoCard[5][5]);
void printbingo(int BingoCard[5][5]);
int pickanum(int BingoCard[5][5],int picked[75]);
int checknum(int BingoCard[5][5], int pickanum);
int checkrow(int BingoCard[5][5],int finish);
int checkcolumn(int BingoCard[5][5],int finish);
int checkdiagonal(int BingoCard[5][5]);



void fillbingo (int BingoCard[5][5])  //function to fill bingo using random number 
{
	int i,j,k,count,g;
	int random;
	int high= 15;
	int low = 0;
	srand(time(0));
	int num =15;
	for ( i = 0; i<5;i++)
	{
		j = 0;
		while (j < 5)
		{
		    count = 0;
			random= rand()% num+1; 
			if (random<= high && random > low)
			{   
    			for (k = j; k >= 0; k--){
        			if (BingoCard[k][i] != random){
            			count ++; 
    			    }
    		    }
			if ((count -1) == j){
			    BingoCard[j][i] = random;
			    j++;
			}
			else{
	        g =1;
			}
			}
		}
		while(random != BingoCard[j][i]) 
		{
			random= rand()% num; 
			BingoCard[j][i] = random;
			 

			
		}
        high = high+ 15;
		low = low + 15;
		num = num + 15;
		
		printf("\n");
	}
	BingoCard[2][2] = 0;	 //sets the bingo value at position 2,2 to 0.
}
	


void printbingo(int BingoCard[5][5]) // function to print bingo
{
	printf("B\t\tI\t\tN\t\tG\t\tO\t\t\n");  //printing BINGO.
	int a,b,c;
	printf("--------------------------------------------------------------------------");
	printf("\n");
	for (b = 0; b<5;b++)
	{
		printf("|");
		for (c = 0 ; c < 5; c++)
		{
			if (BingoCard[b][c] == 0)
			{
				printf("%c\t|\t", 'X');
				
			}
			else
			{
				printf("%d\t|\t",BingoCard[b][c]);
			}
		}
			
        printf("--------------------------------------------------------------------------");
  		printf("\n");
  				

	}
		

}


int pickanum(int BingoCard[5][5],int picked[75])   // function to pick a number from the array 
{
	srand(time(0));
	int j,temp,i;
	int found=0;
	int position;
	temp=1;
	while(temp)
	{
		j = rand() % 75+1 ;   // picks a random number from 1 to 75
		
	    for ( i = 0; i<=75; i++)
	    {
		    if(j==picked[i])
		    {
		        found=1;
		        i=100;
		    }
			else
			{
				found=0;
			}
		}    
		if(found==0)
		{
			for(i=0;i<75;i++)
			{
				if(picked[i]==0)
				{
					picked[i]=j;
					i=100;
				}
			}
			
			if (j>=1 && j<=15)
			{
				printf("The next number is B%d",j);
			}
			else if (j>=15 && j<=30)
			{
				printf("The next number is I%d",j);
			}
			else if (j>=31 && j<=45)
			{
				printf("The next number is N%d",j);
			}
			else if (j>=46 && j<=60)
			{
				printf("The next number is G%d",j);
			}
			else if (j>=61 && j<=75)
			{
				printf("The next number is O%d",j);
			}
			temp=0;   
		}
    }
	return j;
	
}
int checknum(int BingoCard[5][5], int pickanum) // function to check if the picked number is in the bingo card or not
{
    int i,j;
    char dec;
    
    printf("\n Do you have have it? (Y/N)");  //asking the user if the number picked is in their bingo card or not
    scanf(" %c", &dec);
    int success =0;
    if ( dec == 'Y')
    {
		for ( i = 0; i <= 5; i++)
		{
			for (j= 0 ; j<= 5;j++)
			{
		        if (BingoCard[i][j]==pickanum)
		        {
		            BingoCard[i][j]=0;
		            success = 1;
		            j = 6;
		        }
			}  
		         
		}        
		       
		if(success==0)
		{
			printf("That value is not in your BINGO card - are you trying to cheat??");
		}
		
	}
    
	return success;
}
		
int checkrow(int BingoCard[5][5],int finish) // to check if the row is filled
{
    int i,j,count;
    for (i = 0; i<=5; i++)
    {
        count=0;
    	for (j = 0 ; j<=5; j++)
	    {	
	    	if(BingoCard[i][j]==0)
				count++;
        }
        if (count==6)
        {
        	
	        return 1;
        }
    }
        
    return finish;
}

int checkcolumn(int BingoCard[5][5],int finish) //to check if the column is filled
{
    int i,j,count;
    for (j = 0; j<6; j++)
    {
        count=0;
    	for (i = 0 ; i<6; i++)
	    {	
	        if(BingoCard[i][j]==0)
			count++;
        }
        if (count==6)
        {
	        
	        return 1;
        }
    }
    
return finish;
}

int checkdiagonal(int BingoCard[5][5]) //to check if the diagonal part is filled to make a bingo
{
	int diag = 0;
	if ((BingoCard[0][0]==0 && BingoCard[1][1]==0 && BingoCard[2][2]==0 && BingoCard[3][3]==0 && BingoCard[4][4]==0 )||(BingoCard[4][0]==0 && BingoCard[3][1]==0 && BingoCard[2][2]==0 && BingoCard[1][3]==0 && BingoCard[0][4]==0))
	{
		diag = 1;
	}
	return diag;
}



int main() // passing the functions here in the main 
{
    int i,j,b,c,as,row,col,cd,finish=0;
    int success= 0;
	int BingoCard[5][5]; 
	int picked[75];
	
	for(i=0;i<75;i++)
	{
	    picked[i]=0;
	}
	
	
	int x=1;
    fillbingo(BingoCard);
    while(x)
    {
        printbingo(BingoCard);
        as=pickanum(BingoCard,picked);
        checknum(BingoCard,as);
        col=checkcolumn(BingoCard,finish);
        row=checkrow(BingoCard,finish);
        cd = checkdiagonal(BingoCard);

        if(col == 1)
        {
			printbingo(BingoCard);
			printf("You filled a column - BINGOO!!!\n"); // prints if a column is filled
            x = 0;
        }
	    else if(row == 1)
        {
			printbingo(BingoCard);
			printf("You filled a row - BINGOO!!!\n"); //prints if a row is filled
            x=0;
	    }
	    else if ((row==1)&& (col==1))
	    {
	    	printbingo(BingoCard);
	    	printf("You filled a row and a column- BINGOO!!!\n"); //prints if both row and column fills at a time
	    }
	    if(cd==1)
	    {
	    	printbingo(BingoCard);
	    	printf("You filled a diagnol-BINGOO!!"); //prints if diagonal is filled
	    	x = 0;
	    }
		printf("\n");
	
        
    }

return 0;

}
     
